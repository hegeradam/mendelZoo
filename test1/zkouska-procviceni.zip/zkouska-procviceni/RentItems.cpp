//
// Created by Renáta Hegerová on 13.01.2026.
//

#include "RentItems.h"

#include <iostream>
#include <ostream>

#include "Customer.h"
#include "Item.h"

RentItems::RentItems(float time) {
    m_time = time;
    m_total = 0;
}
void RentItems::addItem(Item *item) {
    if (item->rentOne()) {
        m_items.push_back(item);
    } else {
        std::cout << "Item '" << item->getName()
                  << "' neni skladem!" << std::endl;
    }
}
void RentItems::addCustomer(Customer* customer) {
    m_customers.push_back(customer);
}
float RentItems::cash(Item* item) {
    m_total += m_time * item->getPrice();
    return m_total;
}
void RentItems::printInfo() {
        std::cout << "\n-----Pujcky-----" << std::endl;

    for (Customer* c : m_customers) {
        c->printInfo();
    }

    for (Item* i : m_items) {
        i->printInfo();
    }

    std::cout << "]]]]]] Total Price * Time: " << m_total << std::endl;
    std::cout << "]]]]]] Rent time: " << m_time << " hours" << std::endl;

}
