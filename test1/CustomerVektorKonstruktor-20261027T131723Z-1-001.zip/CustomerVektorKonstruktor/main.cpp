
#include <iostream>
#include <string>
#include <list>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <stdexcept>

class Customer {
private:
    std::string m_name;
    int m_id;
    double m_baseDiscount;
    double m_totalSpent;
    inline static int m_nextId = 1;
    double m_currentDiscount;

    void updateDiscount() {
        int bonus = static_cast<int>(m_totalSpent / 10000);
        m_currentDiscount = std::min(20.0, m_baseDiscount + bonus);
    }

public:
    Customer(std::string name) : Customer(name, 5.0) {
    }

    Customer(std::string name, double discount) {
        m_name = name;
        m_id = m_nextId++;
        m_baseDiscount = std::clamp(discount, 0.0, 20.0);
        m_totalSpent = 0;
        m_currentDiscount = m_baseDiscount;
    }

    void addPurchase(double cash) {
        if (cash > 0) {
            m_totalSpent += cash;
            updateDiscount();
        }
    }

    int getId() const {
        return m_id;
    }

    std::string getName() const {
        return m_name;
    }

    double getDiscount() const {
        return m_currentDiscount;
    }

    double getTotalSpent() const {
        return m_totalSpent;
    }

    std::string printInfo() const {
        std::stringstream ss;

        ss << std::fixed << std::setprecision(2);
        ss << "ID: " << m_id << "\n";
        ss << "Name: " << m_name << "\n";
        ss << "Total spent: " << m_totalSpent << " CZK\n";
        ss << "Discount: " << m_currentDiscount << " %\n";

        return ss.str();
    }
};

class Eshop {
private:
    std::list<Customer> m_customers;

public:
    Customer& addCustomer(std::string name) {
        m_customers.emplace_back(name);
        return m_customers.back();
    }

    Customer& addCustomer(std::string name, double discount) {
        m_customers.emplace_back(name, discount);
        return m_customers.back();
    }

    Customer& findCustomer(int id) {
        for (Customer& customer : m_customers) {
            if (customer.getId() == id) {
                return customer;
            }
        }

        throw std::out_of_range("Customer not found!");
    }

    void printCustomers() const {
        for (const Customer& customer : m_customers) {
            std::cout << customer.printInfo() << "\n";
        }
    }

    void printCustomerInfo(int id) {
        std::cout << findCustomer(id).printInfo();
    }
};

int main() {
    Eshop eshop;

    // Creating customers
    Customer& customer1 = eshop.addCustomer("Adam");
    Customer& customer2 = eshop.addCustomer("Petr", 10.0);
    Customer& customer3 = eshop.addCustomer("Karel");

    // Printing all customers
    std::cout << "=== ALL CUSTOMERS ===\n";
    eshop.printCustomers();

    // Adding purchases
    customer1.addPurchase(25000);
    customer2.addPurchase(50000);
    customer3.addPurchase(10000);

    // Printing all customers
    std::cout << "=== ALL CUSTOMERS ===\n";
    eshop.printCustomers();

    // Printing a specific customer
    std::cout << "=== CUSTOMER INFO ===\n";
    eshop.printCustomerInfo(customer2.getId());

    customer2.addPurchase(50000);

    // Printing a specific customer
    std::cout << "=== CUSTOMER INFO ===\n";
    eshop.printCustomerInfo(customer2.getId());

    // Finding a customer and adding another purchase
    Customer& foundCustomer = eshop.findCustomer(customer2.getId());
    foundCustomer.addPurchase(20000);

    std::cout << "\n=== UPDATED CUSTOMER ===\n";
    eshop.printCustomerInfo(foundCustomer.getId());

    return 0;
}