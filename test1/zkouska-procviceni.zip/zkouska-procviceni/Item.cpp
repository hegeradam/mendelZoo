//
// Created by Renáta Hegerová on 13.01.2026.
//

#include "Item.h"

#include <iostream>
#include <ostream>

Item::Item(std::string name, int quantity, float price) {
    m_name = name;
    m_quantity = quantity;
    m_price = price;
}
bool Item::rentOne() {
    if (m_quantity > 0) {
        m_quantity--;
        return true;
    }
    return false;
}
float Item::getPrice() const {
    return m_price;
}
std::string Item::getName() const {
    return m_name;
}
void Item::printInfo() {
    std::cout << "-----ITEM INFO-----" << std::endl;
    std::cout << "Name: " << m_name << std::endl;
    std::cout << "Quantity: " << m_quantity << std::endl;
    std::cout << "Price: " << m_price << std::endl;
}

