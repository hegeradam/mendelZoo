//
// Created by Renáta Hegerová on 13.01.2026.
//

#include "Customer.h"

#include <iostream>
#include <ostream>

int Customer::m_nextId = 1;

Customer::Customer(std::string name) {
    m_name = name;
    m_id = m_nextId++;
}
void Customer::printInfo() {
    std::cout << "-----CUSTOMER INFO-----" << std::endl;
    std::cout << "Name: " << m_name << std::endl;
    std::cout << "Id: " << m_id << std::endl;
}
int Customer::getId() {
    return m_id;
}

