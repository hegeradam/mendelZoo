//
// Created by Renáta Hegerová on 13.01.2026.
//

#ifndef ZKOUSKA_PROCVICENI_ITEM_H
#define ZKOUSKA_PROCVICENI_ITEM_H
#include <string>


class Item {
    private:
        std::string m_name;
        int m_quantity;
        float m_price;
    public:
        Item(std::string name, int quantity, float price);
        void printInfo();
        bool rentOne();
        float getPrice() const;
        std::string getName() const;

};


#endif //ZKOUSKA_PROCVICENI_ITEM_H