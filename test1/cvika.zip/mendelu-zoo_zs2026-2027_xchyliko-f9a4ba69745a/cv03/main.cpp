#include <iostream>
#include <string>

class Account {
private:
    std::string m_ownerName;
    float m_balance = 0.0f;
    float m_withdrawalLimit = 0.0f;
    bool m_isTransparentAccount = false;

public:
    Account() = delete;

    Account(std::string ownerName, float withdrawalLimit) {
        setOwnerName(ownerName);
        setWithdrawalLimit(withdrawalLimit);
    }

    Account(std::string ownerName): Account(ownerName, 500.0f) {
    }

    ~Account() {
        std::cout << "Account of " << m_ownerName << " is being destroyed." << std::endl;
    }

    std::string getOwnerName() {
        return m_ownerName;
    }

    void setOwnerName(std::string ownerName) {
        if (ownerName.empty()) {
            m_ownerName = "Unknown";
            std::cerr << "Owner name cannot be empty. Using 'Unknown' instead." << std::endl;
            return;
        }

        m_ownerName = ownerName;
    }

    float getBalance() {
        return m_balance;
    }

    float getWithdrawalLimit() {
        return m_withdrawalLimit;
    }

    void setWithdrawalLimit(float withdrawalLimit) {
        if (withdrawalLimit < 0.0f) {
            m_withdrawalLimit = 0.0f;
            std::cerr << "Withdrawal limit cannot be negative. Using 0 instead." << std::endl;
            return;
        }

        m_withdrawalLimit = withdrawalLimit;
    }

    bool isTransparentAccount() {
        return m_isTransparentAccount;
    }

    void printInfo() {
        std::cout << "Owner: " << getOwnerName() << "\n"
                  << "Balance: " << getBalance() << " CZK\n"
                  << "Withdrawal limit: " << getWithdrawalLimit() << " CZK\n"
                  << "Transparent account: " << (isTransparentAccount() ? "yes" : "no")
                  << std::endl;
    }

    void depositMoney(float amount) {
        if (amount <= 0.0f) {
            std::cerr << "Deposit amount must be positive." << std::endl;
            return;
        }

        m_balance += amount;
    }

    void withdrawMoney(float amount) {
        if (amount <= 0.0f) {
            std::cerr << "Withdrawal amount must be positive." << std::endl;
            return;
        }

        if (amount > m_balance) {
            std::cerr << "There is not enough money in the account." << std::endl;
            return;
        }

        if (amount > m_withdrawalLimit) {
            std::cerr << "Withdrawal amount exceeds the withdrawal limit." << std::endl;
            return;
        }

        m_balance -= amount;
    }

    void makeTransparent() {
        m_isTransparentAccount = true;
    }
};

int main() {
    Account* accountWithCustomLimit = new Account("Eliska", 1200.0f);
    Account* accountWithStandardLimit = new Account("Petr");
    Account* accountWithInvalidValues = new Account("", -100.0f);

    accountWithCustomLimit->depositMoney(2000.0f);
    accountWithCustomLimit->withdrawMoney(400.0f);
    accountWithCustomLimit->setOwnerName("Alena");
    accountWithCustomLimit->setWithdrawalLimit(1500.0f);
    accountWithCustomLimit->makeTransparent();
    accountWithCustomLimit->withdrawMoney(1600.0f);

    accountWithStandardLimit->depositMoney(-50.0f);
    accountWithStandardLimit->depositMoney(100.0f);
    accountWithStandardLimit->withdrawMoney(-10.0f);
    accountWithStandardLimit->withdrawMoney(200.0f);

    std::cout << "Account with a custom withdrawal limit:" << std::endl;
    accountWithCustomLimit->printInfo();

    std::cout << "\nAccount with the standard withdrawal limit:" << std::endl;
    accountWithStandardLimit->printInfo();

    std::cout << "\nAccount created with invalid values:" << std::endl;
    accountWithInvalidValues->printInfo();

    delete accountWithCustomLimit;
    delete accountWithStandardLimit;
    delete accountWithInvalidValues;

    return 0;
}
