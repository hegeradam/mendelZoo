#include <iostream>
#include <string>

enum class CruiserClass {
    Light,
    Medium,
    Heavy
};

std::string classToString(CruiserClass cruiserClass) {
    switch (cruiserClass) {
        case CruiserClass::Light:
            return "Light";
        case CruiserClass::Medium:
            return "Medium";
        case CruiserClass::Heavy:
            return "Heavy";
        default:
            return "Unknown";
    }
}

class ImperialCruiser {
public:
    std::string m_yards;
    std::string m_model;
    CruiserClass m_class;
    int m_price;

    void printInfo() {
        std::cout
            << "Cruiser info: \n"
            << "Yards: " << m_yards << "\n"
            << "Model: " << m_model << "\n"
            << "Class: " << classToString(m_class) << "\n"
            << "Credits: " << m_price << std::endl;
    }

    void setYards(std::string yards) {
        if (inputValid(yards)) {
            m_yards = yards;
        } else {
            m_yards = "Not set";
            std::cout << "ImperialCruiser::setYards: input is not valid" << std::endl;
        }
    }

    void setClass(CruiserClass cruiserClass) {
        m_class = cruiserClass;
    }

    void setModel(std::string model) {
        m_model = model;
    }

    void setPrice(int credits) {
        m_price = credits;
    }

    std::string getYards() {
        return m_yards;
    }

    std::string getModel() {
        return m_model;
    }

    CruiserClass getClass() {
        return m_class;
    }

    int getPrice() {
        return m_price;
    }

    bool inputValid(std::string input) {
        return input != "";
    }
};

int main() {
    ImperialCruiser* suppressor = new ImperialCruiser();
    suppressor->setYards("Kuat Drive Yards");
    suppressor->setClass(CruiserClass::Light);
    suppressor->setModel("Arquitens");
    suppressor->setPrice(5000000);
    suppressor->printInfo();

    delete suppressor;
    return 0;
}
