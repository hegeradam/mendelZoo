#include <iostream>

class RunClub {
public:
    std::string m_name;
    std::string m_runningType;
    float m_routeLengthKm = 0.0;
    int m_meetingsPerMonth = 0;
    int m_maxParticipants = 0;
    float m_monthlyFee = 0.0;

    void setName(std::string name) {
        if (name == "") {
            std::cout << "Club name cannot be empty." << std::endl;
        } else {
            m_name = name;
        }
    }

    std::string getName() {
        return m_name;
    }

    void setRunningType(std::string runningType) {
        if (runningType == "") {
            std::cout << "Running type cannot be empty." << std::endl;
        } else {
            m_runningType = runningType;
        }
    }

    std::string getRunningType() {
        return m_runningType;
    }

    void setMeetingsPerMonth(int meetingsPerMonth) {
        if (meetingsPerMonth < 0) {
            std::cout << "Meetings per month cannot be negative." << std::endl;
        } else {
            m_meetingsPerMonth = meetingsPerMonth;
        }
    }

    int getMeetingsPerMonth() {
        return m_meetingsPerMonth;
    }

    void setMaxParticipants(int maxParticipants) {
        if (maxParticipants <= 0) {
            std::cout << "Maximum number of participants must be positive." << std::endl;
        } else {
            m_maxParticipants = maxParticipants;
        }
    }

    int getMaxParticipants() {
        return m_maxParticipants;
    }

    void setRouteLengthKm(float routeLengthKm) {
        if (routeLengthKm <= 0) {
            std::cout << "Route length must be positive." << std::endl;
        } else {
            m_routeLengthKm = routeLengthKm;
        }
    }

    float getRouteLengthKm() {
        return m_routeLengthKm;
    }

    void setMonthlyFee(float monthlyFee) {
        if (monthlyFee < 0) {
            std::cout << "Monthly fee cannot be negative." << std::endl;
        } else {
            m_monthlyFee = monthlyFee;
        }
    }

    float getMonthlyFee() {
        return m_monthlyFee;
    }

    void readInfo() {
        std::cout << "Enter information about your run club" << std::endl;

        std::string runClubName;
        std::cout << "Club name: ";
        std::getline(std::cin, runClubName);
        setName(runClubName);

        std::string runningType;
        std::cout << "Running type: ";
        std::getline(std::cin, runningType);
        setRunningType(runningType);

        float routeLengthKm;
        std::cout << "Usual route length in kilometers: ";
        std::cin >> routeLengthKm;
        setRouteLengthKm(routeLengthKm);

        int meetingsPerMonth;
        std::cout << "Meetings per one month: ";
        std::cin >> meetingsPerMonth;
        setMeetingsPerMonth(meetingsPerMonth);

        int maxParticipants;
        std::cout << "Maximum number of participants per run: ";
        std::cin >> maxParticipants;
        setMaxParticipants(maxParticipants);

        float monthlyFee;
        std::cout << "Monthly fee: ";
        std::cin >> monthlyFee;
        setMonthlyFee(monthlyFee);

        std::cin.ignore();
    }

    void printInfo() {
        std::cout << "*** Run Club ***" << "\n"
        << "Name: " << m_name << "\n"
        << "Running type: " << m_runningType << "\n"
        << "Usual route length in kilometers: " << m_routeLengthKm << "\n"
        << "Meetings per one month: " << m_meetingsPerMonth << "\n"
        << "Monthly fee: " << m_monthlyFee << "\n"
        << "Maximum of participants per run: " << m_maxParticipants << std::endl;
    }
};

class BookClub {
public:
    std::string m_name;
    std::string m_genre;
    int m_meetingsPerMonth = 0;
    int m_participantCount = 0;
    int m_meetingDurationMinutes = 0;
    float m_monthlyFee = 0.0;

    void setName(std::string name) {
        if (name == "") {
            std::cout << "Club name cannot be empty." << std::endl;
        } else {
            m_name = name;
        }
    }

    std::string getName() {
        return m_name;
    }

    void setGenre(std::string genre) {
        if (genre == "") {
            std::cout << "Book genre cannot be empty." << std::endl;
        } else {
            m_genre = genre;
        }
    }

    std::string getGenre() {
        return m_genre;
    }

    void setMeetingsPerMonth(int meetingsPerMonth) {
        if (meetingsPerMonth < 0) {
            std::cout << "Meetings per month cannot be negative." << std::endl;
        } else {
            m_meetingsPerMonth = meetingsPerMonth;
        }
    }

    int getMeetingsPerMonth() {
        return m_meetingsPerMonth;
    }

    void setParticipantCount(int participantCount) {
        if (participantCount <= 0) {
            std::cout << "Number of participants must be positive." << std::endl;
        } else {
            m_participantCount = participantCount;
        }
    }

    int getParticipantCount() {
        return m_participantCount;
    }

    void setMeetingDurationMinutes(int meetingDurationMinutes) {
        if (meetingDurationMinutes <= 0) {
            std::cout << "Meeting duration must be positive." << std::endl;
        } else {
            m_meetingDurationMinutes = meetingDurationMinutes;
        }
    }

    int getMeetingDurationMinutes() {
        return m_meetingDurationMinutes;
    }

    void setMonthlyFee(float monthlyFee) {
        if (monthlyFee < 0) {
            std::cout << "Monthly fee cannot be negative." << std::endl;
        } else {
            m_monthlyFee = monthlyFee;
        }
    }

    float getMonthlyFee() {
        return m_monthlyFee;
    }

    void readInfo() {
        std::cout << "Enter information about your book club" << std::endl;

        std::string bookClubName;
        std::cout << "Club name: ";
        std::getline(std::cin, bookClubName);
        setName(bookClubName);

        std::string bookGenre;
        std::cout << "Book genre: ";
        std::getline(std::cin, bookGenre);
        setGenre(bookGenre);

        int meetingsPerMonth;
        std::cout << "Meetings per one month: ";
        std::cin >> meetingsPerMonth;
        setMeetingsPerMonth(meetingsPerMonth);

        int participantCount;
        std::cout << "Number of participants: ";
        std::cin >> participantCount;
        setParticipantCount(participantCount);

        int meetingDurationMinutes;
        std::cout << "Meeting duration in minutes: ";
        std::cin >> meetingDurationMinutes;
        setMeetingDurationMinutes(meetingDurationMinutes);

        float monthlyFee;
        std::cout << "Monthly fee: ";
        std::cin >> monthlyFee;
        setMonthlyFee(monthlyFee);

        std::cin.ignore();
    }

    void printInfo() {
        std::cout << "*** Book Club ***" << "\n"
        << "Name: " << m_name << "\n"
        << "Genre: " << m_genre << "\n"
        << "Meetings per one month: " << m_meetingsPerMonth << "\n"
        << "Number of participants: " << m_participantCount << "\n"
        << "Meeting duration in minutes: " << m_meetingDurationMinutes << "\n"
        << "Monthly fee: " << m_monthlyFee << std::endl;
    }
};

class CookingClub {
public:
    std::string m_name;
    std::string m_cuisineFocus;
    int m_participantCount = 0;
    int m_meetingDurationMinutes = 0;
    float m_monthlyFee = 0.0;

    void setName(std::string name) {
        if (name == "") {
            std::cout << "Club name cannot be empty." << std::endl;
        } else {
            m_name = name;
        }
    }

    std::string getName() {
        return m_name;
    }

    void setCuisineFocus(std::string cuisineFocus) {
        if (cuisineFocus == "") {
            std::cout << "Cuisine focus cannot be empty." << std::endl;
        } else {
            m_cuisineFocus = cuisineFocus;
        }
    }

    std::string getCuisineFocus() {
        return m_cuisineFocus;
    }

    void setParticipantCount(int participantCount) {
        if (participantCount <= 0) {
            std::cout << "Number of participants must be positive." << std::endl;
        } else {
            m_participantCount = participantCount;
        }
    }

    int getParticipantCount() {
        return m_participantCount;
    }

    void setMeetingDurationMinutes(int meetingDurationMinutes) {
        if (meetingDurationMinutes <= 0) {
            std::cout << "Meeting duration must be positive." << std::endl;
        } else {
            m_meetingDurationMinutes = meetingDurationMinutes;
        }
    }

    int getMeetingDurationMinutes() {
        return m_meetingDurationMinutes;
    }

    void setMonthlyFee(float monthlyFee) {
        if (monthlyFee < 0) {
            std::cout << "Monthly fee cannot be negative." << std::endl;
        } else {
            m_monthlyFee = monthlyFee;
        }
    }

    float getMonthlyFee() {
        return m_monthlyFee;
    }

    void readInfo() {
        std::cout << "Enter information about your cooking club" << std::endl;

        std::string cookingClubName;
        std::cout << "Club name: ";
        std::getline(std::cin, cookingClubName);
        setName(cookingClubName);

        std::string cuisineFocus;
        std::cout << "Cuisine focus: ";
        std::getline(std::cin, cuisineFocus);
        setCuisineFocus(cuisineFocus);

        int participantCount;
        std::cout << "Number of participants: ";
        std::cin >> participantCount;
        setParticipantCount(participantCount);

        int meetingDurationMinutes;
        std::cout << "Meeting duration in minutes: ";
        std::cin >> meetingDurationMinutes;
        setMeetingDurationMinutes(meetingDurationMinutes);

        float monthlyFee;
        std::cout << "Monthly fee: ";
        std::cin >> monthlyFee;
        setMonthlyFee(monthlyFee);
    }

    void printInfo() {
        std::cout << "*** Cooking Club ***" << "\n"
        << "Name: " << m_name << "\n"
        << "Cuisine focus: " << m_cuisineFocus << "\n"
        << "Number of participants: " << m_participantCount << "\n"
        << "Meeting duration in minutes: " << m_meetingDurationMinutes << "\n"
        << "Monthly fee: " << m_monthlyFee << std::endl;
    }
};

int main() {
    RunClub* myRunClub = new RunClub();
    BookClub* myBookClub = new BookClub();
    CookingClub* myCookingClub = new CookingClub();

    myRunClub->readInfo();
    myBookClub->readInfo();
    myCookingClub->readInfo();

    std::cout << "\nClub information" << std::endl;
    std::cout << "================" << std::endl;
    myRunClub->printInfo();
    std::cout << std::endl;
    myBookClub->printInfo();
    std::cout << std::endl;
    myCookingClub->printInfo();

    delete myRunClub;
    delete myBookClub;
    delete myCookingClub;

    return 0;
}
