#include <iostream>
#include <vector>

class Customer{
    static int s_counter;
    int m_id;
    std::string m_name;
    float m_discount;
    float m_totalPurchasesCzk;
public:
    Customer(std::string name, float discount){
        m_id = s_counter;
        s_counter += 1;
        m_name = name; // TODO kontrola vstupu
        m_discount = discount;
        m_totalPurchasesCzk = 0;
    }

    // pozor delegovat
    Customer(std::string name): Customer(name, 5){
    }

    int getId(){
        return m_id;
    }

    std::string getName(){
        return m_name;
    }

    float getDiscount(){
        return m_discount;
    }

    void addPurchase(float purchasePriceCzk){
        updateDiscount(purchasePriceCzk);
        m_totalPurchasesCzk += purchasePriceCzk;
    }

    static int getMaxId(){
        return s_counter;
    }

private:
    void updateDiscount(float purchasePriceCzk){
        // pokazde kdyz zakaznik prekroci 10k tak se zvysi sleva o procento

        // int beforePurchase = m_totalPurchasesCzk/10000; // opravit prevedeni typu
        int beforePurchase = static_cast<int>(m_totalPurchasesCzk / 10000); // korektni prevedeni typu

        int afterPurchase = static_cast<int>((m_totalPurchasesCzk + purchasePriceCzk) / 10000);
        int difference = afterPurchase-beforePurchase;
        if (afterPurchase>beforePurchase){
            if (m_discount+difference <= 20){
                m_discount += difference;
            } else {
                m_discount = 20;
            }
        }
    }
};

int Customer::s_counter = 0; // pozor inicializovat

class CustomerRegister{
    std::vector<Customer*> m_customers; // novinka
public:
    Customer* createCustomer(std::string name, std::string type){ // tovarni metoda
        Customer* newCustomer = nullptr;

        if (type == "basic") {
            newCustomer = new Customer(name, 5);
        } else if (type == "corporate") {
            newCustomer = new Customer(name, 3);
        } else if (type == "vip") {
            newCustomer = new Customer(name, 10);
        } else {
            std::cerr << "Such customer type does not exist." << std::endl;
            return nullptr;
        }

        m_customers.push_back(newCustomer); // pridani do seznamu
        return newCustomer;
    }

    ~CustomerRegister(){
        for(auto customer: m_customers){
            delete customer;
        }
    }


};

int main() {
    CustomerRegister* customerRegister = new CustomerRegister();
    Customer* c1 = customerRegister->createCustomer("Eliska", "vip");
    c1->addPurchase(11000);

    delete customerRegister;
    return 0;
}
