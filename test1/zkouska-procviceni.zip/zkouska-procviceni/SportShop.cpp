//
// Created by Renáta Hegerová on 13.01.2026.
//

#include "SportShop.h"

#include <iostream>
#include <ostream>

SportShop::SportShop() {
    std::cout << "Sport shop were created!" << std::endl;
}
SportShop::~SportShop() {
    std::cerr << "Sport shop were destroyed!" << std::endl;
}

void SportShop::printRentItems() {
    std::cout << "RentItems:" << std::endl;

    for (const auto & rent :  m_rentItems) {
        rent->printInfo();
        return;
    }
}

void SportShop::printCustomer() {
    std::cout << "Customer:" << std::endl;

    for (const auto & customer : m_customers) {
        customer->printInfo();
        return;
    }
}

void SportShop::printItems() {
    std::cout << "Items:" << std::endl;

    for (const auto & item : m_items) {
        item->printInfo();
        return;
    }
}

void SportShop::searchItem(std::string name) {
    std::cout << "Search Item by id:" << std::endl;
    std::cin >> name;

    for (const auto & item : m_items) {
        if (name == item->getName()) {
            item->printInfo();
            return;
        }
    }
}

void SportShop::searchCustomer(int id) {
    std::cout << "Search Customer:" << std::endl;
    std::cin >> id;

    for (const auto & customer : m_customers) {
        if (id == customer->getId()) {
            customer->printInfo();
            return;
        }
    }
}


