#include <iostream>
#include <string>

class Task {
private:
    int m_id;
    std::string m_title;
    float m_time;
    static int m_nextId;

public:
    Task(std::string title) {
        this->m_id = m_nextId++;
        this->m_title = title;
        this->m_time = 1.0f;
    }

    Task(std::string title, float hours) {
        this->m_id = m_nextId++;
        this->m_title = title;
        this->m_time = hours;
    }

    void getId() {
        std::cout << "Task ID: " << m_id << "\n";
    }

    std::string getTitle() {
        return m_title;
    }

    float getTime() {
        return m_time;
    }

    void printInfo() {
        std::cout << "ID: " << m_id << "\n";
        std::cout << "Title: " << m_title << "\n";
        std::cout << "Hours: " << m_time << "\n\n";
    }
};
int Task::m_nextId = 1;

class Employee {
private:
    std::string m_name;
    float m_contract;
    float m_timeWorked;

public:
    Employee(std::string name, float contract) {
        this->m_name = name;
        this->m_contract = contract;
        this->m_timeWorked = 0;
    }

    std::string getName() {
        return m_name;
    }

    void getContract() {
        std::cout << "Contract size: " << m_contract << "\n";
    }

    void getTimeWorked() {
        std::cout << "Time worked: " << m_timeWorked << "\n";
    }

    void setContract(float newContract) {
        if (newContract >= 0 && newContract <= 1) {
            this->m_contract = newContract;
        } else {
            std::cout << "Error: Contract must be between 0 and 1!" << "\n";
        }
    }

    void printInfo() {
        std::cout << "Name: " << m_name << "\n";
        std::cout << "Contract: " << m_contract << "\n";
        std::cout << "Time worked: " << m_timeWorked << "\n\n";
    }

    void addWork(Task* task) {
        float m_hours = task->getTime() + m_timeWorked;

        if (m_hours > 40) {
            std::cout << "Error: Max hours must be between 0 and 40!" << "\n";
        } else {
            m_timeWorked += task->getTime();

            if (m_timeWorked > 20) {
                m_contract = 1;
            }
        }
        std::cout << m_name << " worked on task " << task->getTitle()
                  << " for " << task->getTime() << " hours. Total: "
                  << m_timeWorked << "\n";
    }

    void resetTimeWorked() {
        m_timeWorked = 0;
        std::cout << "Time worked has been reset for " << m_name << "\n";
    }
};


int main() {

    Task* newTask1 = new Task("New Task", 2.5);
    Task* newTask2 = new Task("Front-end", 20);
    Task* newTask3 = new Task("RestAPI", 20.5);

    Employee* newEmployee1 = new Employee("Heger", 0);

    newTask1->printInfo();
    newTask2->printInfo();
    newTask3->printInfo();
    newEmployee1->printInfo();

    newEmployee1->addWork(newTask1);
    newEmployee1->addWork(newTask2);
    newEmployee1->addWork(newTask3);

    newEmployee1->printInfo();

    newEmployee1->resetTimeWorked();

    newEmployee1->printInfo();

    delete newTask1;
    delete newTask2;
    delete newTask3;
    delete newEmployee1;

    return 0;
}
