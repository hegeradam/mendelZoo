#include <iostream>

#include "SportShop.h"

int main() {

    SportShop* sportShop = new SportShop();

    Customer* customer1 = new Customer("Pepa");
    Customer* customer2 = new Customer("Adam");

    customer1->printInfo();
    customer2->printInfo();

    Item* item1 = new Item("Lyze", 10, 600);
    Item* item2 = new Item("Snowboard", 5, 800);

    item1->printInfo();
    item2->printInfo();

    RentItems* rent1 = new RentItems(2);

    rent1->addCustomer(customer1);

    rent1->addItem(item1);
    rent1->cash(item1);

    rent1->addItem(item2);
    rent1->cash(item2);

    rent1->printInfo();

    RentItems* rent2 = new RentItems(3);

    rent2->addCustomer(customer2);

    rent2->addItem(item2);
    rent2->cash(item2);
    rent2->printInfo();

    item1->printInfo();
    item2->printInfo();

    delete sportShop;

    return 0;
}
