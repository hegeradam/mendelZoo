//
// Created by Renáta Hegerová on 13.01.2026.
//

#ifndef ZKOUSKA_PROCVICENI_CUSTOMER_H
#define ZKOUSKA_PROCVICENI_CUSTOMER_H
#include <string>


class Customer {
    private:
        std::string m_name;
        int m_id;
        static int m_nextId;
    public:
        Customer(std::string name);
        void printInfo();
        int getId();
};


#endif //ZKOUSKA_PROCVICENI_CUSTOMER_H