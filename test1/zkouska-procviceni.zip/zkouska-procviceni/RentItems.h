//
// Created by Renáta Hegerová on 13.01.2026.
//

#ifndef ZKOUSKA_PROCVICENI_RENTITEMS_H
#define ZKOUSKA_PROCVICENI_RENTITEMS_H

#include "Customer.h"
#include "Item.h"
#include <vector>

class RentItems {
    private:
        std::vector<Item*> m_items;
        std::vector<Customer*> m_customers;
        float m_time;
        float m_total;
    public:
        RentItems(float time);
        void addItem(Item* item);
        void addCustomer(Customer* customer);
        void printInfo();
        float cash(Item* item);
};


#endif //ZKOUSKA_PROCVICENI_RENTITEMS_H