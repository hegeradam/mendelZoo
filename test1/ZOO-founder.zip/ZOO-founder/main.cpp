#include <iostream>
#include <string>
#include <vector>

using namespace std;

enum CustomerType
{
    NORMAL,
    COMPANY,
    VIP
};

class Customer
{
private:
    int m_id;
    string m_name;
    CustomerType m_type;
    double m_discount;

public:
    Customer(int id, string name, CustomerType type)
    {
        m_id = id;
        m_name = name;
        m_type = type;

        if (type == NORMAL)
        {
            m_discount = 5.0;
        }
        else if (type == COMPANY)
        {
            m_discount = 3.0;
        }
        else if (type == VIP)
        {
            m_discount = 10.0;
        }
    }

    int getId()
    {
        return m_id;
    }

    string getName()
    {
        return m_name;
    }

    CustomerType getType()
    {
        return m_type;
    }

    double getDiscount()
    {
        return m_discount;
    }

    void printInfo()
    {
        cout << "ID: " << m_id << endl;
        cout << "Jmeno: " << m_name << endl;
        cout << "Sleva: " << m_discount << " %" << endl;
    }
};

class CustomerManager
{
private:
    vector<Customer> m_customers;
    int m_nextId;

public:
    CustomerManager()
    {
        m_nextId = 1;
    }

    Customer createCustomer(CustomerType type, string name)
    {
        Customer customer(m_nextId, name, type);

        m_customers.push_back(customer);
        m_nextId++;

        cout << "Zakaznik byl vytvoren." << endl;

        return customer;
    }

    Customer* findCustomerById(int id)
    {
        for (int i = 0; i < m_customers.size(); i++)
        {
            if (m_customers[i].getId() == id)
            {
                return &m_customers[i];
            }
        }

        cout << "Chyba: Zakaznik nebyl nalezen." << endl;
        return nullptr;
    }

    vector<Customer*> findCustomersByName(string name)
    {
        vector<Customer*> foundCustomers;

        for (int i = 0; i < m_customers.size(); i++)
        {
            if (m_customers[i].getName() == name)
            {
                foundCustomers.push_back(&m_customers[i]);
            }
        }

        return foundCustomers;
    }
};

int main()
{
    CustomerManager manager;

    manager.createCustomer(NORMAL, "Jan Novak");
    manager.createCustomer(COMPANY, "Firma ABC");
    manager.createCustomer(VIP, "Petr Svoboda");
    manager.createCustomer(NORMAL, "Jan Novak");

    cout << "\n--- Vyhledani podle ID ---" << endl;

    Customer* customer = manager.findCustomerById(3);

    if (customer != nullptr)
    {
        customer->printInfo();
    }

    cout << "\n--- Vyhledani podle jmena ---" << endl;

    vector<Customer*> customers =
        manager.findCustomersByName("Jan Novak");

    for (int i = 0; i < customers.size(); i++)
    {
        customers[i]->printInfo();
        cout << "----------------" << endl;
    }

    return 0;
}