#include <iostream>
#include <string>

class WorkLogger{
    std::string m_workLog;
    static WorkLogger* s_instance; // staticka promenna - jen jedna instance singletonu

    WorkLogger(){ // pozor private konstruktor
        m_workLog = "\n*** Log of work: ***\n";
    }
public:
    void logWork(std::string developerName, std::string taskTitle, float taskcomplexity){
        std::string newRecord = developerName + ": " + taskTitle + " (" + std::to_string(taskcomplexity) + " hours)\n";
        m_workLog += newRecord;
    }

    void printWorkLog(){
        std::cout << m_workLog << std::endl;
    }

    static WorkLogger* createWorkLogger(){
        if (s_instance == nullptr){
            s_instance = new WorkLogger();
        }
        return s_instance;
    }
};

WorkLogger* WorkLogger::s_instance = nullptr; // vytvari pamet pro statickou promennou

class Task {
    int m_id;
    std::string m_title;
    float m_complexityInHours;
    static int s_taskCounter; // staticka promenna

public:
    Task(std::string title, float complexityInHours) {
        setTitle(title);
        setComplexityInHours(complexityInHours);
        s_taskCounter++;
        m_id = s_taskCounter;
    }

    Task(std::string title): Task(title, 1.0f) {} // delegovani konstruktoru

    ~Task() {
        std::cout << "deleting task..." << std::endl;
    }

    int getId() {
        return m_id;
    }

    float getComplexityInHours() {
        return m_complexityInHours;
    }

    std::string getTitle() {
        return m_title;
    }

private:
    void setTitle(std::string title) {
        if (title != "") {
            m_title = title;
        } else {
            m_title = "No title";
            std::cerr << "Error: No title set!" << std::endl;
        }
    }

    void setComplexityInHours(float complexityInHours) {
        if (complexityInHours >= 0) {
            m_complexityInHours = complexityInHours;
        } else {
            m_complexityInHours = 0;
            std::cerr << "Error: complexity in hours must be >= 0."
            << std::endl;
        }
    }
};

int Task::s_taskCounter = 0; // vytvoreni promenne v pameti

class Employee {
    std::string m_name;
    float m_workedHours;
    float m_contractSize; // velikost uvazku napr. 0.5

public:
    Employee(std::string name, float hoursPerWeekContract) {
        m_workedHours = 0;
        setName(name);
        setContractSize(hoursPerWeekContract);
    }

    void setContractSize(float contractSize) {
        if ((contractSize > 0) && (contractSize <= 1)) {
            m_contractSize = contractSize;
        } else {
            m_contractSize = 1.0;
            std::cerr << "Error: contract size must be between 0 and 1"
            << std::endl;
        }
    }

    void printInfo() {
        std::cout << "Employee name: " << m_name << std::endl;
        std::cout << "Worked hours: " << m_workedHours << std::endl;
        std::cout << "Contract size: " << m_contractSize << std::endl;
    }

    void resetWorkedHours() {
        m_workedHours = 0;
    }

    void addWork(Task* task) { // predavani ukazatelem
        float taskHours = task->getComplexityInHours();
        float weeklyHoursLimit = 40.0f * m_contractSize;

        if (m_workedHours + taskHours > weeklyHoursLimit) {
            std::cerr << "Error: This employee cannot work more this week."
            << std::endl;
            return;
        }

        m_workedHours += taskHours;

        WorkLogger* logger = WorkLogger::createWorkLogger();
        logger->logWork(m_name, task->getTitle(), taskHours);

        std::cout << "Added task " << task->getTitle() << " with hours " << taskHours
        << " to employee " << m_name << std::endl;
    }

private:
    void setName(std::string name) {
        if (name != "") {
            m_name = name;
        } else {
            m_name = "No name";
            std::cerr << "Error: name cannot be empty" << std::endl;
        }
    }
};

int main() {
    Task* teaching = new Task("Teach ZOO on Monday", 20.0f);
    Task* teaching2 = new Task("Teach ZOO on Tuesday", 1.5f);

    Employee* eliska = new Employee("Eliska", 0.5);
    eliska->addWork(teaching);

    std::cout << "*** New week ***" << std::endl;
    eliska->resetWorkedHours();

    eliska->addWork(teaching2);
    eliska->printInfo();

    WorkLogger* logger = WorkLogger::createWorkLogger();
    logger->printWorkLog();

    delete teaching;
    delete teaching2;
    delete eliska;
    return 0;
}
