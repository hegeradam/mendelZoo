//
// Created by Renáta Hegerová on 13.01.2026.
//

#ifndef ZKOUSKA_PROCVICENI_SPORTSHOP_H
#define ZKOUSKA_PROCVICENI_SPORTSHOP_H

#include "Customer.h"
#include "Item.h"
#include "RentItems.h"
#include <vector>

class SportShop {
    private:
        std::vector<RentItems*> m_rentItems;
        std::vector<Customer*> m_customers;
        std::vector<Item*> m_items;
    public:
        SportShop();
        ~SportShop();
        void printCustomer();
        void printItems();
        void printRentItems();
        void searchItem(std::string name);
        void searchCustomer(int id);
};


#endif //ZKOUSKA_PROCVICENI_SPORTSHOP_H